using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Newtonsoft.Json;
using Shared;
using System.Text;

namespace Demo.Pages
{
    public class LoginModel : PageModel
    {
        [BindProperty] public InputModel Input { get; set; }
        [TempData] public string StatusMessage { get; set; }

        public class InputModel
        {
            public string Email { get; set; }
            public string Password { get; set; }
        }
        public void OnGet()
        {
        }

        public async Task<IActionResult> OnPost()
        {
            if (ModelState.IsValid)
            {
                HttpClient client = new();
                var model = new LoginViewModel
                {
                    Email = Input.Email,
                    Password = Input.Password
                };

                var jsonData = JsonConvert.SerializeObject(model);

                var content = new StringContent(jsonData, Encoding.UTF8, "application/json");
                var response = await client.PostAsync("https://localhost:7242/api/auth/Login", content);

                var responseBody = await response.Content.ReadAsStringAsync();

                var responseObject = JsonConvert.DeserializeObject<UserManagerResponse>(responseBody);

                if (responseObject.IsSuccess)
                { 
                    return LocalRedirect("~/LoginSuccess?qs=" +responseObject.Message);
                }
                else
                {
                    StatusMessage = "Error! Invalid login attempt";
                    return Page();
                }
            }
            StatusMessage = "Error! Kindly provide your valid login crednetials to continue.";
            return Page();
        }
    }
}
