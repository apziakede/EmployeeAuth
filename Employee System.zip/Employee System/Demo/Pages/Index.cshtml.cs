﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Newtonsoft.Json;
using Shared;
using System.Text;

namespace Demo.Pages
{
    public class IndexModel : PageModel
    {
        private readonly ILogger<IndexModel> _logger;

        public IndexModel(ILogger<IndexModel> logger)
        {
            _logger = logger;
        }
       [BindProperty] public InputModel Input { get; set; }
       [TempData] public string StatusMessage { get; set; }

        public class InputModel
        {
            public string Email { get; set; }
            public string Password { get; set; }
            public string ConfirmPassword { get; set; }
        }
        public void OnGet()
        {

        }

        public async Task<IActionResult> OnPost()
        {
            HttpClient client = new();
            var model = new RegisterViewModel
            {
                ConfirmPassword = Input.ConfirmPassword,
                Email = Input.Email,
                Password = Input.Password
            };

            var jsonData = JsonConvert.SerializeObject(model);

            var content = new StringContent(jsonData, Encoding.UTF8, "application/json");
            var response = await client.PostAsync("https://localhost:7242/api/auth/Register", content);

            var responseBody= await response.Content.ReadAsStringAsync();

            var responseObject=JsonConvert.DeserializeObject<UserManagerResponse>(responseBody);

            if (responseObject.IsSuccess)
            {
                StatusMessage=responseObject.Message;
                return RedirectToPage();
            }
            else
            {
             StatusMessage = "Error! Could not create user";
                return Page();
            }

        }
    }
}