using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Newtonsoft.Json;
using Shared;
using System.Text;

namespace Demo.Pages
{
    public class LoginSuccessModel : PageModel
    {
        [TempData] public string StatusMessage { get; set; }
        public List<WeatherForecast> weatherForecastList = new();
        public async Task<IActionResult> OnGet(string qs)
        {
            if (!string.IsNullOrWhiteSpace(qs))
            {
                string accessToken = qs;
                HttpClient client = new();

                client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", accessToken);

                var response = await client.GetAsync("https://localhost:7242/weatherforecast");

                var responseBody = await response.Content.ReadAsStringAsync();

                var weatherForcasts = JsonConvert.DeserializeObject<IEnumerable<WeatherForecast>>(responseBody);
                weatherForecastList =  weatherForcasts.ToList();
            }
            return Page();
        }
    }
}
