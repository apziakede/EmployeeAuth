using DbUp.Helpers;
using DbUp;
using EmployeeSystem.Data;
using EmployeeSystem.Interfaces;
using EmployeeSystem.Services;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Configuration.UserSecrets;
using Microsoft.IdentityModel.Tokens;
using Shared;
using System.Text;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

//Configure EF with Sql services
builder.Services.AddDbContext<AppDbContext>(options =>
{
    options.UseSqlServer(builder.Configuration.GetConnectionString("Default"));
});

builder.Services.AddIdentity<IdentityUser, IdentityRole>(options =>
{
    options.Password.RequireDigit = true;
    options.Password.RequireLowercase = true;
    options.Password.RequireUppercase = true;
    options.Password.RequiredLength = 4;
}).AddEntityFrameworkStores<AppDbContext>()
.AddDefaultTokenProviders();

builder.Services.AddAuthentication(options =>
{
    options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
}).AddJwtBearer(options =>
{
    options.TokenValidationParameters = new Microsoft.IdentityModel.Tokens.TokenValidationParameters
    {
        ValidateIssuer = true,
        ValidateAudience = true,
        ValidAudience = builder.Configuration["AuthSettings:Audience"],
        ValidIssuer = builder.Configuration["AuthSettings:Issuer"],
        RequireExpirationTime = true,
        IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(builder.Configuration["AuthSettings:Key"])),
        ValidateIssuerSigningKey = true
    };
});

builder.Services.AddScoped<IUserService, UserService>();

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}
void DBMigrationScript()
{
    string? conStr = builder.Configuration.GetConnectionString("Default");
    EnsureDatabase.For.SqlDatabase(conStr);
    var upgrader = DeployChanges.To.SqlDatabase(conStr)
        .WithScriptsFromFileSystem(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "SqlScripts", "db"))
        .WithTransactionPerScript()
       .JournalTo(new NullJournal())
        .LogToConsole()
        .Build();
    upgrader.PerformUpgrade();
}

void TableMigrationScript()
{
    string? conStr = builder.Configuration.GetConnectionString("Default");
    EnsureDatabase.For.SqlDatabase(conStr);
    var upgrader = DeployChanges.To.SqlDatabase(conStr)
        .WithScriptsFromFileSystem(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "SqlScripts", "SqlTables"))
        .WithTransactionPerScript()
       .JournalTo(new NullJournal())
        .LogToConsole()
        .Build();
    upgrader.PerformUpgrade();
}

void StoredProcMigrationScript()
{
    string? conStr = builder.Configuration.GetConnectionString("Default");
    EnsureDatabase.For.SqlDatabase(conStr);
    var upgrader = DeployChanges.To.SqlDatabase(conStr)
        .WithScriptsFromFileSystem(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "SqlScripts", "SqlProcs"))
        .WithTransactionPerScript()
      .JournalTo(new NullJournal())
        .LogToConsole()
        .Build();
    upgrader.PerformUpgrade();
}
 
 DBMigrationScript();
 TableMigrationScript();
 StoredProcMigrationScript();

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
