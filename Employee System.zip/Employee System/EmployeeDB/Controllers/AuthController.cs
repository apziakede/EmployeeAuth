﻿using EmployeeSystem.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Shared;

namespace EmployeeSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private IUserService _userService;

        public AuthController(IUserService userService)
        {
            _userService = userService;
        }

        // /api/auth/register
        [HttpPost("Register")]
        public async Task<IActionResult> RegisterAsync(RegisterViewModel model)
        {
            if(ModelState.IsValid)
            {
                var result =await _userService.RegisterUserAsync(model);
                if(result.IsSuccess)
                    return Ok(result);

                return BadRequest(result);
            }

            return BadRequest("Kindly provide all the required fields");
        }

        // /api/auth/login
        [HttpPost("Login")]
        public async Task<IActionResult> LoginAsync(LoginViewModel model)
        {
            if(ModelState.IsValid)
            {
                var result= await _userService.LoginUserAsync(model);
                if(result.IsSuccess)
                    return Ok(result);

                return BadRequest(result);
            }
            return BadRequest("Invalid login credentials");
        }
    }
}
