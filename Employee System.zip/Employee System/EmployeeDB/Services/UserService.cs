﻿using EmployeeSystem.Interfaces;
using Microsoft.AspNetCore.Identity;
using Microsoft.IdentityModel.Tokens;
using Shared;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace EmployeeSystem.Services
{
    public class UserService : IUserService
    {
        private UserManager<IdentityUser> _userManager;
        private IConfiguration _configuration;


        public UserService(UserManager<IdentityUser> userManager, IConfiguration configuration)
        {
            _userManager = userManager;
            _configuration = configuration;
        }
        public async Task<UserManagerResponse> RegisterUserAsync(RegisterViewModel model)
        {
           if(model == null)
                throw new NullReferenceException("Register model is null");

            if (model.Password != model.ConfirmPassword)
                return new UserManagerResponse
                {
                    Message = "Confirm password does not match the password.",
                    IsSuccess = false
                };

            var identityUser = new IdentityUser
            {
                Email = model.Email,
                UserName = model.Email,
            };

            var result=await _userManager.CreateAsync(identityUser, model.Password);
            if (result.Succeeded)
            {
                //TODO: Send confirmation email
                return new UserManagerResponse
                {
                     Message="User created successfully!",
                     IsSuccess = true
                };
            }
            return new UserManagerResponse
            {
                Message = "Could not create the user",
                IsSuccess = false,
                Errors = result.Errors.Select(x => x.Description)
            };
        }

        public async Task<UserManagerResponse> LoginUserAsync(LoginViewModel model)
        {
            var user= await _userManager.FindByEmailAsync(model.Email);
            if (model == null)
                throw new NullReferenceException("Login model is null");

            if (model.Password.IsNullOrEmpty())
            {
                return new UserManagerResponse
                {
                    Message = "Password field cannot be empty.",
                    IsSuccess = false
                };
            }
           
            if (user == null)
            {
                return new UserManagerResponse
                {
                    Message = "User not found.",
                    IsSuccess = false
                };
            }

            var result = await _userManager.CheckPasswordAsync(user, model.Password);

            if(!result)
                return new UserManagerResponse
                {
                    Message = "Invalid Password provided.",
                    IsSuccess = false
                };

            var claims = new[]
            {
                new Claim(ClaimTypes.Email, model.Email),
                new Claim(ClaimTypes.NameIdentifier, user.Id)
            };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["AuthSettings:Key"]));

            var token = new JwtSecurityToken(
                issuer: _configuration["AuthSettings:Issuer"],
                audience: _configuration["AuthSettings:Audience"],
                claims: claims,
                expires: DateTime.UtcNow.AddDays(1),
                signingCredentials: new SigningCredentials(key, SecurityAlgorithms.HmacSha256)
                );
            string tokenStr = new JwtSecurityTokenHandler().WriteToken(token);

           return new UserManagerResponse
            {
                Message = tokenStr,
                IsSuccess = true,
                ExpireDate=token.ValidTo
            };
        }
    }
}
